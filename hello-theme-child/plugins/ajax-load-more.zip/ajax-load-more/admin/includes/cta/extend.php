<div class="clear"></div>
<div class="call-out">
	<?php _e('Unlock additional templates with the <a href="https://connekthq.com/plugins/ajax-load-more/add-ons/custom-repeaters/?utm_source=WP%20Admin&utm_medium=CustomRepeaters%20Extend&utm_campaign=Custom%20Repeaters" target="_parent">Custom Repeaters add-on</a>', 'ajax-load-more'); ?>
	<a class="cnkt-button" href="https://connekthq.com/plugins/ajax-load-more/add-ons/custom-repeaters/?utm_source=WP%20Admin&utm_medium=CustomRepeaters%20Extend&utm_campaign=Custom%20Repeaters" target="_blank">
		<?php _e('More Info', 'ajax-load-more'); ?>
	</a>
</div>
