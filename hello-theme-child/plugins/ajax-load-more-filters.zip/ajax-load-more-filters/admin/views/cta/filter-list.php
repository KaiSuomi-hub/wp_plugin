<div class="cta">
   <h3><?php _e('Your Filters', 'ajax-load-more-filters'); ?></h3>
   <div class="cta-inner filter-listing">
      <?php echo alm_list_all_filters($filter_id); ?> 
   </div>
</div>